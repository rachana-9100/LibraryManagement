package com.example.LibraryManagement;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import com.example.LibraryManagement.repository.UserRepository;
import com.example.LibraryManagement.service.LibraryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LibraryServiceTest {

    @InjectMocks
    private LibraryService libraryService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private BookRepository bookRepository;

    @Mock
    private CheckoutRecordRepository checkoutRecordRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Test 1: Check out a book successfully
    @Test
    public void testCheckoutBook_Success() {
        User user = new User();
        user.setUserId(1L);
        user.setUsername("chandu123");
        user.setEmail("chandu@example.com");
        user.setPassword("chandu@123");

        Book book = new Book();
        book.setId(1L);
        book.setTitle("The Great Gatsby");
        book.setAvailableCopies(5);  // 5 copies available

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        String result = libraryService.checkoutBook(1L, 1L);

        assertEquals("Successfully checked out! Due date: " + LocalDate.now().plusWeeks(3), result);
        verify(bookRepository).save(book); // Verify that the book was updated
    }

    // Test 2: Add user to waitlist if all copies are checked out
    @Test
    public void testAddUserToWaitlist_AllCopiesCheckedOut() {
        User user = new User();
        user.setUserId(1L);
        user.setUsername("chandu123");

        Book book = new Book();
        book.setId(1L);
        book.setTitle("The Great Gatsby");
        book.setAvailableCopies(0); // No available copies

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        String result = libraryService.addUserToWaitlist(1L, 1L);

        assertEquals("You have been added to the waitlist for this book.", result);
        verify(bookRepository).save(book); // Verify that the book's waitlist was updated
    }


    // Test 3: Ensure books can only be checked out for a maximum of 3 weeks
    @Test
    public void testCheckoutBook_ValidDuration() {
        User user = new User();
        user.setUserId(1L);
        Book book = new Book();
        book.setId(1L);
        book.setAvailableCopies(5); // Available copies

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        // Simulate checking out a book
        String result = libraryService.checkoutBook(1L, 1L);

        // Validate due date is set correctly
        assertEquals("Successfully checked out! Due date: " + LocalDate.now().plusWeeks(3), result);
    }

    // Test 4: Check if a user has overdue books
    @Test
    public void testHasOverdueBooks_True() {
        User user = new User();
        user.setUserId(1L);

        CheckoutRecord checkoutRecord = new CheckoutRecord();
        checkoutRecord.setUser(user);
        checkoutRecord.setDueDate(LocalDate.now().minusDays(1)); // Overdue book

        List<CheckoutRecord> checkoutRecords = new ArrayList<>();
        checkoutRecords.add(checkoutRecord);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(checkoutRecordRepository.findByUser(user)).thenReturn(checkoutRecords);

        assertTrue(libraryService.hasOverdueBooks(1L)); // Should return true for overdue books
    }

    // Test 5: Get user waitlist position for a given book
    @Test
    public void testGetUserWaitlistPosition_Success() {
        User user = new User();
        user.setUserId(1L);

        Book book = new Book();
        book.setId(1L);
        book.setTitle("The Great Gatsby");

        // Simulating user on the waitlist
        book.getWaitlist().add(user);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        String result = libraryService.getUserWaitlistPosition(1L, 1L);

        assertEquals("You are number 1 on the waitlist for this book.", result);
    }
}
