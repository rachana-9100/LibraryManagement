package com.example.LibraryManagement.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "LIBRARY_USER") // Table name in the database for library users
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate user ID
    @Column(name = "USER_ID") // Column name for the user ID in the database
    private Long userId;

    private String email; // User's email address
    private String name; // User's name
    private String password; // User's password
    private String username; // User's username for login

    // Many-to-many relationship between users and checked-out books
    @ManyToMany
    @JoinTable(
            name = "USER_CHECKED_OUT_BOOKS", // Join table name
            joinColumns = @JoinColumn(name = "USER_ID"), // Column for user ID
            inverseJoinColumns = @JoinColumn(name = "BOOK_ID") // Column for book ID
    )
    private List<Book> checkedOutBooks = new ArrayList<>(); // List of books checked out by the user

    // One-to-many relationship with checkout records
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CheckoutRecord> checkoutRecords = new ArrayList<>(); // List of checkout records associated with the user

    // Default constructor
    public User() {
    }

    // Getters and Setters
    public Long getUserId() {
        return userId; // Return the user ID
    }

    public void setUserId(Long userId) {
        this.userId = userId; // Set the user ID
    }

    public String getEmail() {
        return email; // Return the user's email
    }

    public void setEmail(String email) {
        this.email = email; // Set the user's email
    }

    public String getName() {
        return name; // Return the user's name
    }

    public void setName(String name) {
        this.name = name; // Set the user's name
    }

    public String getPassword() {
        return password; // Return the user's password
    }

    public void setPassword(String password) {
        this.password = password; // Set the user's password
    }

    public String getUsername() {
        return username; // Return the username field value
    }

    public void setUsername(String username) {
        this.username = username; // Set the username field value
    }

    public List<Book> getCheckedOutBooks() {
        return checkedOutBooks; // Return the list of checked out books
    }

    public void setCheckedOutBooks(List<Book> checkedOutBooks) {
        this.checkedOutBooks = checkedOutBooks; // Set the list of checked out books
    }

    public void addCheckedOutBook(Book book) {
        this.checkedOutBooks.add(book); // Add a book to the checked out list
    }

    public List<CheckoutRecord> getCheckoutRecords() {
        return checkoutRecords; // Return the list of checkout records
    }

    public void setCheckoutRecords(List<CheckoutRecord> checkoutRecords) {
        this.checkoutRecords = checkoutRecords; // Set the list of checkout records
    }
}
