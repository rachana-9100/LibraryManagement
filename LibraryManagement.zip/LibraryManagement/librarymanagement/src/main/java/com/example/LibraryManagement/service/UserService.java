package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;  // Use java.util.List, not Hibernate's List

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Fetch all users
    public List<User> getAllUsers() {
        // Return a list of all users from the repository
        return userRepository.findAll();  // This returns a java.util.List
    }

    // Fetch all users along with their checked-out books
    public List<User> getAllUsersWithCheckedOutBooks() {
        // Return a list of all users and their associated checked-out books
        return userRepository.findAll();  // Fetch all users and their relations (checked-out books)
    }

    // Fetch a user by their ID
    public User getUserById(Long userId) {
        // Return the user with the specified ID, or null if not found
        return userRepository.findById(userId).orElse(null);
    }

    // Save the user after issuing a book
    public void saveUser(User user) {
        // Save the user object to the database
        userRepository.save(user);
    }
}
