package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.BookRepository; // Ensure this is imported
import com.example.LibraryManagement.service.BookService;
import com.example.LibraryManagement.service.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import java.util.List;

@Controller
public class BookController {

    // Autowire the BookService to handle book-related logic
    @Autowired
    private BookService bookService;

    // Autowire the BookRepository to interact with the Book entity in the database
    @Autowired
    private BookRepository bookRepository;

    // Autowire the LibraryService to handle library operations such as checkout and waitlist
    @Autowired
    private LibraryService libraryService;

    /**
     * Displays the checkout book page.
     * This method is mapped to the URL "/checkoutbook" and responds to GET requests.
     *
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "checkout_book.html" for rendering.
     */
    @GetMapping("/checkoutbook")
    public String showCheckoutBookPage(Model model) {
        // Fetch all available books from the repository
        List<Book> books = bookRepository.findAll();
        model.addAttribute("books", books);  // Add the list of books to the model
        return "checkout_book";  // Points to the Thymeleaf template 'checkout_book.html'
    }

    /**
     * Displays the index page with featured books.
     * This method is mapped to the root URL ("/") and responds to GET requests.
     *
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "index.html" for rendering.
     */
    @GetMapping("/")
    public String showIndexPage(Model model) {
        // Fetch the featured books from the service
        List<Book> featuredBooks = bookService.getFeaturedBooks();
        model.addAttribute("books", featuredBooks);  // Add the featured books to the model
        return "index";  // Points to the Thymeleaf template 'index.html'
    }

    /**
     * Search for books by a query string (case-insensitive).
     * This method is mapped to the URL "/search" and responds to GET requests.
     *
     * @param query The search query entered by the user.
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "search_results.html" for rendering.
     */
    @GetMapping("/search")
    public String searchBooks(@RequestParam("query") String query, Model model) {
        // Fetch matching books using the search query
        List<Book> searchResults = bookService.searchBooks(query);
        model.addAttribute("books", searchResults);  // Add the search results to the model
        model.addAttribute("query", query);  // Pass the search query to the view
        return "search_results";  // Points to 'search_results.html'
    }

    /**
     * Handles the book checkout process.
     * This method is mapped to the URL "/checkoutbook" and responds to POST requests.
     *
     * @param bookId The ID of the book to be checked out.
     * @param session The HttpSession object to get the logged-in user.
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "checkout_book.html" or redirect to login if user is not authenticated.
     */
    @PostMapping("/checkoutbook")
    public String checkoutBook(@RequestParam Long bookId, HttpSession session, Model model) {
        // Get the logged-in user from the session
        User user = (User) session.getAttribute("user");

        // If the user is logged in, proceed with the book checkout process
        if (user != null) {
            String result = libraryService.checkoutBook(user.getUserId(), bookId);  // Handle book checkout
            model.addAttribute("message", result);  // Add result message (success or failure) to the model

            // Fetch updated list of books and add to the model
            List<Book> books = bookRepository.findAll();
            model.addAttribute("books", books);
            return "checkout_book";  // Return to checkout_book view with the message
        } else {
            // Redirect to login page if the user is not authenticated
            return "redirect:/userlogin";
        }
    }

    /**
     * View the user's waitlist.
     * This method is mapped to the URL "/waitlist" and responds to GET requests.
     *
     * @param session The HttpSession object to get the logged-in user.
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "waitlist.html" or redirect to login if user is not authenticated.
     */
    @GetMapping("/waitlist")
    public String viewWaitlist(HttpSession session, Model model) {
        // Get the logged-in user from the session
        User user = (User) session.getAttribute("user");

        // If the user is not logged in, redirect to login page
        if (user == null) {
            return "redirect:/userlogin";
        }

        // Fetch the list of books the user is waitlisted for
        List<Book> waitlistedBooks = libraryService.getWaitlistedBooksForUser(user.getUserId());

        // Add the waitlisted books to the model for display
        model.addAttribute("waitlistedBooks", waitlistedBooks);
        return "waitlist";  // Points to the Thymeleaf template 'waitlist.html'
    }

    /**
     * Add a user to the waitlist for a specific book.
     * This method is mapped to the URL "/waitlist" and responds to POST requests.
     *
     * @param bookId The ID of the book to add the user to the waitlist.
     * @param session The HttpSession object to get the logged-in user.
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "checkout_book.html" or redirect to login if user is not authenticated.
     */
    @PostMapping("/waitlist")
    public String addUserToWaitlist(@RequestParam Long bookId, HttpSession session, Model model) {
        // Get the logged-in user from the session
        User user = (User) session.getAttribute("user");

        // If the user is logged in, proceed with adding them to the waitlist
        if (user != null) {
            String result = libraryService.addUserToWaitlist(user.getUserId(), bookId);  // Handle adding to waitlist
            model.addAttribute("message", result);  // Add result message to the model

            // Fetch the updated list of books and add to the model
            List<Book> books = bookRepository.findAll();
            model.addAttribute("books", books);
            return "checkout_book";  // Return to checkout_book page with the message
        } else {
            // Redirect to login page if the user is not authenticated
            return "redirect:/userlogin";
        }
    }

    /**
     * Get the user's position in the waitlist for a specific book.
     * This method is mapped to the URL "/waitlistPosition" and responds to POST requests.
     *
     * @param bookId The ID of the book to check the waitlist position.
     * @param session The HttpSession object to get the logged-in user.
     * @param model The Model object to pass data to the view.
     * @return The Thymeleaf template "checkout_book.html" or redirect to login if user is not authenticated.
     */
    @PostMapping("/waitlistPosition")
    public String getWaitlistPosition(@RequestParam Long bookId, HttpSession session, Model model) {
        // Get the logged-in user from the session
        User user = (User) session.getAttribute("user");

        // If the user is logged in, proceed with fetching the waitlist position
        if (user != null) {
            // Get the user's position on the waitlist for the given book
            String result = libraryService.getUserWaitlistPosition(user.getUserId(), bookId);
            model.addAttribute("message", result);  // Add the position message to the model

            // Fetch the updated list of books and add to the model
            model.addAttribute("books", bookRepository.findAll());

            return "checkout_book";  // Return the updated view
        } else {
            // Redirect to login page if the user is not authenticated
            return "redirect:/userlogin";
        }
    }
}
