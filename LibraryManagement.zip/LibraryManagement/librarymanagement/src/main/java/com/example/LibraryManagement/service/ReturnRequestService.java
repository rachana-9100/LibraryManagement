package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.ReturnRequest;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.model.ReturnStatus;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import com.example.LibraryManagement.repository.ReturnRequestRepository;
import com.example.LibraryManagement.repository.UserRepository;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Transactional
@Service  // Marks this class as a Spring Service component
public class ReturnRequestService {

    @Autowired
    private ReturnRequestRepository returnRequestRepository;  // Inject ReturnRequest repository

    @Autowired
    private BookRepository bookRepository;  // Inject Book repository

    @Autowired
    private UserRepository userRepository;  // Inject User repository

    @Autowired
    private CheckoutRecordRepository checkoutRecordRepository;  // Inject CheckoutRecord repository

    // Method to create a return request
    public String createReturnRequest(Long userId, Long bookId) {
        // Fetch user and book from the database by their IDs
        User user = userRepository.findById(userId).orElse(null);
        Book book = bookRepository.findById(bookId).orElse(null);

        // Check if the user or book is not found, return an error message
        if (user == null || book == null) {
            return "User or Book not found.";
        }

        // Find all the user's checkout records for the specified book
        List<CheckoutRecord> checkoutRecords = checkoutRecordRepository.findByUserAndBook(user, book);

        // Check if no active checkout records exist, return an error message
        if (checkoutRecords.isEmpty()) {
            return "No active checkout found for this user and book.";
        }

        // Process each checkout record
        for (CheckoutRecord checkoutRecord : checkoutRecords) {
            // If a return request has already been made, return a message
            if (checkoutRecord.getReturnStatus() == ReturnStatus.REQUESTED) {
                return "Return has already been requested for this checkout.";
            }

            // Set the return status to 'REQUESTED'
            checkoutRecord.setReturnStatus(ReturnStatus.REQUESTED);
            checkoutRecordRepository.save(checkoutRecord);  // Save the updated checkout record

            // Create a new return request
            ReturnRequest returnRequest = new ReturnRequest();
            returnRequest.setUser(user);  // Set the user in the return request
            returnRequest.setBook(book);  // Set the book in the return request
            returnRequest.setCheckoutRecord(checkoutRecord);  // Link the return request to the checkout record
            returnRequest.setRequestDate(LocalDateTime.now());  // Set the current request date
            returnRequest.setStatus("pending");  // Set default status as 'pending'
            returnRequest.setApproved(false);  // Initially set as not approved

            // Save the return request to the database
            returnRequestRepository.save(returnRequest);
        }

        return "Return request submitted successfully for the checked-out books!";
    }

    // Method to approve a return request
    public String approveReturnRequest(Long requestId) {
        // Find the return request by its ID
        Optional<ReturnRequest> returnRequestOpt = returnRequestRepository.findById(requestId);
        if (returnRequestOpt.isPresent()) {
            ReturnRequest returnRequest = returnRequestOpt.get();  // Get the return request
            returnRequest.setApproved(true);  // Set approved to true
            returnRequest.setStatus("approved");  // Set status to 'approved'
            returnRequest.setApprovalDate(LocalDateTime.now());  // Set the current approval date
            returnRequestRepository.save(returnRequest);  // Save the updated return request

            // Get the associated checkout record and update its return status
            CheckoutRecord checkoutRecord = returnRequest.getCheckoutRecord();
            if (checkoutRecord != null) {  // Ensure the checkout record exists
                checkoutRecord.setReturnStatus(ReturnStatus.APPROVED);  // Set return status to 'APPROVED'
                checkoutRecordRepository.save(checkoutRecord);  // Save the updated checkout record
            } else {
                return "Checkout record not found for this return request.";
            }

            // Update the book's available copies (increment by 1)
            Book book = returnRequest.getBook();
            book.setAvailableCopies(book.getAvailableCopies() + 1);
            bookRepository.save(book);  // Save the updated book

            return "Return request approved successfully!";
        } else {
            return "Return request not found.";
        }
    }

    // Method to reject a return request
    public String rejectReturnRequest(Long requestId) {
        // Find the return request by its ID
        Optional<ReturnRequest> returnRequestOpt = returnRequestRepository.findById(requestId);
        if (returnRequestOpt.isPresent()) {
            ReturnRequest returnRequest = returnRequestOpt.get();  // Get the return request
            returnRequest.setApproved(false);  // Set approved to false
            returnRequest.setStatus("rejected");  // Set status to 'rejected'
            returnRequest.setApprovalDate(null);  // Clear the approval date when rejected
            returnRequestRepository.save(returnRequest);  // Save the updated return request

            return "Return request rejected successfully!";
        } else {
            return "Return request not found.";
        }
    }

    // Method to get all return requests
    public List<ReturnRequest> getAllReturnRequests() {
        return returnRequestRepository.findAll();  // Fetch all return requests from the repository
    }
}
