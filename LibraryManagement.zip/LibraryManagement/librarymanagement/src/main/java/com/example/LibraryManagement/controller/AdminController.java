package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.ReturnRequest;
import com.example.LibraryManagement.service.ReturnRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AdminController {

    // Autowire the ReturnRequestService to handle business logic for return requests
    @Autowired
    private ReturnRequestService returnRequestService;

    /**
     * Method to display the Admin Dashboard.
     * This method is mapped to the URL "/admin/dashboard".
     * It fetches any necessary data to display on the admin dashboard page.
     */
    @GetMapping("/admin/dashboard")
    public String showAdminDashboard(Model model) {
        // You can add logic here to populate the dashboard with any required data
        return "admin_dashboard"; // Return the Thymeleaf template for the admin dashboard
    }

    /**
     * Method to view all return requests.
     * This method is mapped to the URL "/admin/return-requests".
     * It fetches all return requests and adds them to the model to be displayed in the view.
     */
    @GetMapping("/admin/return-requests")
    public String viewReturnRequests(Model model) {
        // Get a list of all return requests from the service layer
        List<ReturnRequest> returnRequests = returnRequestService.getAllReturnRequests();

        // Add the list of return requests to the model to be rendered in the view
        model.addAttribute("returnRequests", returnRequests);

        // Add an attribute 'view' to conditionally render the return requests table in the dashboard
        model.addAttribute("view", "returnRequests");

        // Return the admin dashboard template, which will display the return requests
        return "admin_dashboard";
    }

    /**
     * Method to approve or reject a return request.
     * This method is mapped to the URL "/admin/approveReturnRequest".
     * It receives the requestId and approval decision, then processes the request accordingly.
     */
    @PostMapping("/admin/approveReturnRequest")
    public String approveReturnRequest(@RequestParam Long requestId,
                                       @RequestParam boolean approve,
                                       RedirectAttributes redirectAttributes) {
        // If the request is approved, call the service method to approve the return request
        if (approve) {
            returnRequestService.approveReturnRequest(requestId);
            // Add a success message to be displayed after redirection
            redirectAttributes.addFlashAttribute("message", "Return request approved successfully!");
        } else {
            // If the request is rejected, call the service method to reject the return request
            returnRequestService.rejectReturnRequest(requestId);
            // Add a rejection message to be displayed after redirection
            redirectAttributes.addFlashAttribute("message", "Return request rejected successfully!");
        }

        // Redirect back to the admin dashboard after processing the request
        return "redirect:/admin/dashboard";
    }

}
