package com.example.LibraryManagement.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity  // Marks this class as a JPA entity, mapping it to a table in the database
@Table(name = "RETURN_REQUEST")  // Specifies the table name in the database
public class ReturnRequest {

    @Id  // Marks this field as the primary key of the entity
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generates the ID value for new records
    private Long id;

    @ManyToOne  // Many return requests can be associated with one user
    @JoinColumn(name = "user_id", nullable = false)  // Foreign key column referencing the user
    private User user;  // Reference to the User entity

    @ManyToOne  // Many return requests can be associated with one book
    @JoinColumn(name = "book_id", nullable = false)  // Foreign key column referencing the book
    private Book book;  // Reference to the Book entity

    @Column(name = "request_date", nullable = false)  // Column for the date when the return request was made
    private LocalDateTime requestDate;  // Timestamp of when the return request was created

    @Column(name = "approval_date")  // Column for the date when the return request was approved or rejected
    private LocalDateTime approvalDate;  // Timestamp of when the request was processed (approved/rejected)

    @Column(name = "status", nullable = false)  // Status of the request (e.g., pending, approved, rejected)
    private String status = "pending";  // Default status is set to "pending"

    @Column(name = "approved", nullable = false)  // Indicates whether the return request was approved
    private boolean approved = false;  // Default value is 'false', meaning the request is not approved initially

    // Reference to the related CheckoutRecord (to track which record the return belongs to)
    @ManyToOne
    @JoinColumn(name = "checkout_record_id", nullable = false)  // Foreign key column referencing the checkout record
    private CheckoutRecord checkoutRecord;

    // Getter method for requestDate (returns the date the return request was made)
    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    // Getter method for status (returns the status of the return request)
    public String getStatus() {
        return status;
    }

    // Getters and Setters for each field
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    public LocalDateTime getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(LocalDateTime approvalDate) {
        this.approvalDate = approvalDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isApproved() {
        return approved;  // Getter for the 'approved' field
    }

    public void setApproved(boolean approved) {
        this.approved = approved;  // Setter for the 'approved' field
    }

    public CheckoutRecord getCheckoutRecord() {
        return checkoutRecord;
    }

    public void setCheckoutRecord(CheckoutRecord checkoutRecord) {
        this.checkoutRecord = checkoutRecord;
    }
}
