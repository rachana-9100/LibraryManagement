package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.Admin;
import com.example.LibraryManagement.repository.AdminRepository;
import org.slf4j.Logger;
import com.example.LibraryManagement.service.UserService;  // <-- Import for user-related operations
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminLoginController {

    // Logger for logging info and warning messages
    private static final Logger logger = LoggerFactory.getLogger(AdminLoginController.class);

    // Autowire the AdminRepository to interact with the Admin entity in the database
    @Autowired
    private AdminRepository adminRepository;

    // Autowire UserService for potential user-related operations
    @Autowired
    private UserService userService;

    /**
     * Display the admin login page.
     * This method is mapped to the URL "/adminlogin" and responds to GET requests.
     *
     * @return the name of the Thymeleaf template for admin login (admin_login.html).
     */
    @GetMapping("/adminlogin")
    public String showAdminLoginForm() {
        return "admin_login"; // Display the admin login form
    }

    /**
     * Handle the admin login form submission.
     * This method is mapped to the URL "/adminlogin" and responds to POST requests.
     * It processes the login credentials entered by the admin.
     *
     * @param username The admin's username.
     * @param password The admin's password.
     * @param session The HttpSession object to store session-related information.
     * @param model The Model object to pass data to the view.
     * @return the name of the next page (either the dashboard or login page).
     */
    @PostMapping("/adminlogin")
    public String adminLogin(@RequestParam("admin_username") String username,
                             @RequestParam("admin_password") String password,
                             HttpSession session,
                             Model model) {

        // Log the login attempt
        logger.info("Attempting to log in with username: {}", username);

        // Find the admin in the database by username
        Admin admin = adminRepository.findByAdminUsername(username);

        // Check if the admin exists and the password matches
        if (admin != null && admin.getAdminPassword().equals(password)) {
            // Store the admin role in the session to keep the user logged in
            session.setAttribute("role", "admin");
            return "redirect:/admin_dashboard"; // Redirect to the admin dashboard after successful login
        } else {
            // Log an invalid login attempt
            logger.warn("Invalid login attempt for username: {}", username);

            // Add an error message to the model to be displayed on the login page
            model.addAttribute("error", "Invalid username or password");

            // Redirect back to the login page with the error message
            return "admin_login";
        }
    }

    /**
     * Serve the admin dashboard page after successful login.
     * This method is mapped to the URL "/admin_dashboard" and responds to GET requests.
     * It checks the session to ensure the user is logged in as an admin.
     *
     * @param session The HttpSession object to check if the user is logged in.
     * @return the name of the Thymeleaf template for the admin dashboard (admin_dashboard.html).
     */
    @GetMapping("/admin_dashboard")
    public String showAdminDashboard(HttpSession session) {
        // Check if the user has the "admin" role in the session
        if (!"admin".equals(session.getAttribute("role"))) {
            // If the user is not an admin, redirect them to the admin login page
            return "redirect:/adminlogin";
        }

        // If the user is logged in as an admin, return the admin dashboard page
        return "admin_dashboard";
    }
}
