package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.service.BookService;
import com.example.LibraryManagement.service.UserService;
import com.example.LibraryManagement.service.CheckoutRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class AdminIssueBookController {

    // Inject CheckoutRecordService to handle the book issuing logic
    @Autowired
    private CheckoutRecordService checkoutRecordService;  // Service for handling checkout records

    // Inject BookService to handle book-related operations
    @Autowired
    private BookService bookService;

    // Inject UserService to handle user-related operations
    @Autowired
    private UserService userService;


    /**
     * Display the page where the admin can issue books.
     * The method fetches available books and passes them to the view for issuing.
     *
     * @param model Model object to pass data to the Thymeleaf template
     * @param message A message to display (in case of success or failure) after book issuance
     * @return The Thymeleaf template 'admin_issue_books' to render the view
     */
    @GetMapping("/admin/issue-books")
    public String showIssueBooksPage(Model model, @ModelAttribute("message") String message) {
        // Fetch the list of available books that can be issued
        List<Book> books = bookService.getAvailableBooks();
        model.addAttribute("books", books);  // Add the books list to the model

        // If a message is passed (after redirect), add it to the model to be displayed
        if (!message.isEmpty()) {
            model.addAttribute("message", message);
        }

        // Return the Thymeleaf template for issuing books
        return "admin_issue_books";
    }

    /**
     * Handle the book issuance process when the admin submits the form.
     * This method processes the issuing of a book to a user.
     *
     * @param bookId The ID of the book to be issued
     * @param userId The ID of the user who will receive the book
     * @param redirectAttributes Used to add flash attributes for redirection (e.g., success or failure messages)
     * @return Redirects back to the issue books page to show the updated list of available books
     */
    @PostMapping("/admin/issue-book")
    public String issueBookToUser(
            @RequestParam("bookId") Long bookId,
            @RequestParam("userId") Long userId,
            RedirectAttributes redirectAttributes) {

        // Call the service method to issue the book to the user and return a message
        String message = checkoutRecordService.issueBookToUser(bookId, userId);

        // Add the message as a flash attribute to carry it across redirects (e.g., success or error message)
        redirectAttributes.addFlashAttribute("message", message);

        // Redirect back to the issue books page to refresh the list of available books and show the message
        return "redirect:/admin/issue-books";
    }
}
