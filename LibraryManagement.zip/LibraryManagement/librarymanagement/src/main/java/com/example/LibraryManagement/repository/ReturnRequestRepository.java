package com.example.LibraryManagement.repository;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.ReturnRequest;
import com.example.LibraryManagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository // Marks this interface as a Spring Data repository
public interface ReturnRequestRepository extends JpaRepository<ReturnRequest, Long> {

    // Checks if a return request already exists for a given user and book
    boolean existsByUserAndBook(User user, Book book);

    // Finds all return requests made by a specific user
    List<ReturnRequest> findByUser(User user);

    // Finds all return requests related to a specific book
    List<ReturnRequest> findByBook(Book book);

    // Finds return requests by status (e.g., "pending", "approved", "rejected")
    List<ReturnRequest> findByStatus(String status);

    // Finds return requests by checkout record and status
    // Useful for checking the status of specific checkout records (e.g., "pending")
    List<ReturnRequest> findByCheckoutRecordAndStatus(CheckoutRecord checkoutRecord, String status);

    // Custom query to find return requests by both user and book
    @Query("SELECT rr FROM ReturnRequest rr WHERE rr.user = :user AND rr.book = :book")
    List<ReturnRequest> findByUserAndBook(@Param("user") User user, @Param("book") Book book);

}
