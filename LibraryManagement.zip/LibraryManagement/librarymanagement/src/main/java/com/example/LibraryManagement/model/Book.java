package com.example.LibraryManagement.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity  // Marks this class as a JPA entity, which maps to a database table
@Table(name = "BOOK", uniqueConstraints = {@UniqueConstraint(columnNames = {"title", "author"})})  // Defines the table with a unique constraint on title and author
public class Book {

    @Column(name = "featured")  // Maps the 'featured' field to a column in the database
    private Boolean featured;  // Boolean to allow for null values, indicating if the book is featured or not

    @Id  // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Automatically generates a unique ID for each book
    private Long id;

    private String title;  // Title of the book
    private String author;  // Author of the book
    private int availableCopies;  // Number of copies available in the library
    private LocalDate dueDate;  // Due date for the book if it's checked out
    private LocalDate issueDate;  // Date when the book was issued

    private String coverImageUrl;  // URL to the book cover image

    // Getter and setter for the coverImageUrl field
    public String getCoverImageUrl() {
        return coverImageUrl;
    }

    public void setCoverImageUrl(String coverImageUrl) {
        this.coverImageUrl = coverImageUrl;
    }

    // Many-to-Many relationship with User, representing users who have checked out the book
    @ManyToMany(mappedBy = "checkedOutBooks")
    private List<User> users = new ArrayList<>();

    // Many-to-Many relationship with User for users in the waitlist for this book
    @ManyToMany
    @JoinTable(
            name = "waitlist",  // Specifies the table name for the join
            joinColumns = @JoinColumn(name = "book_id"),  // Column linking to the book ID
            inverseJoinColumns = @JoinColumn(name = "user_id")  // Column linking to the user ID
    )
    private List<User> waitlist = new ArrayList<>();

    // One-to-Many relationship with CheckoutRecord, representing the checkout history of this book
    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CheckoutRecord> checkoutRecords = new ArrayList<>();

    @Transient  // This field is not persisted in the database
    private boolean returnRequested;  // Indicates if a return request has been made for this book

    // Default constructor (required by JPA)
    public Book() {}

    // Constructor to initialize a book with title, author, and available copies
    public Book(String title, String author, int availableCopies) {
        this.title = title;
        this.author = author;
        this.availableCopies = availableCopies;
    }

    // Getters and Setters for fields
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) { this.availableCopies = availableCopies; }

    public boolean isFeatured() {
        return featured;  // Getter for the 'featured' field
    }

    public void setFeatured(boolean featured) {
        this.featured = featured;  // Setter for the 'featured' field
    }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    public LocalDate getIssueDate() { return issueDate; }
    public void setIssueDate(LocalDate issueDate) { this.issueDate = issueDate; }

    public boolean isReturnRequested() { return returnRequested; }
    public void setReturnRequested(boolean returnRequested) { this.returnRequested = returnRequested; }

    public List<User> getUsers() { return users; }
    public void setUsers(List<User> users) { this.users = users; }

    public List<CheckoutRecord> getCheckoutRecords() { return checkoutRecords; }
    public void setCheckoutRecords(List<CheckoutRecord> checkoutRecords) { this.checkoutRecords = checkoutRecords; }

    public List<User> getWaitlist() { return waitlist; }
    public void setWaitlist(List<User> waitlist) { this.waitlist = waitlist; }

    // Adds a user to the waitlist if they are not already on it
    public void addUserToWaitlist(User user) {
        if (!waitlist.contains(user)) {
            waitlist.add(user);  // Add the user to the waitlist
        }
    }
}
