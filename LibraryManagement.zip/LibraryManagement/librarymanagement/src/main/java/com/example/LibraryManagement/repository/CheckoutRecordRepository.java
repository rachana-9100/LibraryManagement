package com.example.LibraryManagement.repository;

import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository  // Indicates that this interface is a Spring Data repository
public interface CheckoutRecordRepository extends JpaRepository<CheckoutRecord, Long> {

    // Find all CheckoutRecords associated with a specific User
    List<CheckoutRecord> findByUser(User user);

    // Find a CheckoutRecord by a specific Book and User
    CheckoutRecord findByBookAndUser(Book book, User user);

    // Check if a CheckoutRecord exists for a given book and user
    boolean existsByBook_IdAndUser_UserId(Long bookId, Long userId);

    // Update the return status of a specific CheckoutRecord
    @Modifying  // Indicates that this query modifies data
    @Query("UPDATE CheckoutRecord c SET c.returnStatus = :status WHERE c.checkoutRecordId = :id")
    void updateReturnStatus(@Param("id") Long id, @Param("status") String status);

    // Modify this method to return a List of CheckoutRecords for a specific User and Book
    List<CheckoutRecord> findByUserAndBook(User user, Book book);

    // Retrieve a single CheckoutRecord by a specific User and Book, returning an Optional
    @Query("SELECT cr FROM CheckoutRecord cr WHERE cr.user = :user AND cr.book = :book")
    Optional<CheckoutRecord> findSingleByUserAndBook(@Param("user") User user, @Param("book") Book book);
}
