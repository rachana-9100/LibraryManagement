package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.service.ReturnRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminReturnRequestController {

    @Autowired
    private ReturnRequestService returnRequestService;

    // Endpoint for approving return requests
    @PostMapping("/approveReturnRequest")
    public String approveReturnRequest(@RequestParam Long requestId, Model model) {
        returnRequestService.approveReturnRequest(requestId);
        model.addAttribute("message", "Return request approved successfully!");
        return "redirect:/admin/dashboard"; // Redirect to the admin dashboard
    }

    // Endpoint for rejecting return requests
    @PostMapping("/rejectReturnRequest")
    public String rejectReturnRequest(@RequestParam Long requestId, Model model) {
        returnRequestService.rejectReturnRequest(requestId);
        model.addAttribute("message", "Return request rejected successfully!");
        return "redirect:/admin/dashboard"; // Redirect to the admin dashboard
    }
}