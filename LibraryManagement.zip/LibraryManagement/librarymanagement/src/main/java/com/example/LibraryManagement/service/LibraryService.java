package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.*;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import com.example.LibraryManagement.repository.ReturnRequestRepository;
import com.example.LibraryManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class LibraryService<userId> {

    @Autowired
    private BookRepository bookRepository; // Repository for accessing book data

    @Autowired
    private ReturnRequestRepository returnRequestRepository; // Repository for handling return requests

    @Autowired
    private UserRepository userRepository; // Repository for accessing user data

    @Autowired
    private CheckoutRecordRepository checkoutRecordRepository; // Repository for handling checkout records

    // Method to allow a user to checkout a book
    public String checkoutBook(Long userId, Long bookId) {
        // Retrieve user and book by their IDs
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Book> optionalBook = bookRepository.findById(bookId);

        // Check if the user exists; if not, return an error message
        if (optionalUser.isEmpty()) {
            return "User not found.";
        }
        // Check if the book exists; if not, return an error message
        if (optionalBook.isEmpty()) {
            return "Book not found.";
        }

        User user = optionalUser.get(); // Get the user object
        Book book = optionalBook.get(); // Get the book object

        // Check for existing checkout records for the user
        List<CheckoutRecord> existingCheckouts = checkoutRecordRepository.findByUser(user);
        for (CheckoutRecord record : existingCheckouts) {
            // If the user already has this book checked out and it is not returned, return an error message
            if (record.getBook().getId().equals(book.getId()) && record.getReturnStatus() != ReturnStatus.APPROVED) {
                return "You already have this book checked out.";
            }
        }

        // Check if the user has any overdue books
        if (hasOverdueBooks(userId)) {
            // If the user has overdue books, deny checkout and return a message
            return "You have overdue books. Please return them before checking out more books.";
        }

        // Check if the book has available copies for checkout
        if (book.getAvailableCopies() > 0) {
            // Create a new checkout record for the user and the book
            CheckoutRecord checkoutRecord = new CheckoutRecord();
            checkoutRecord.setUser(user); // Set the user for the checkout record
            checkoutRecord.setBook(book); // Set the book for the checkout record
            checkoutRecord.setIssueDate(LocalDate.now()); // Set the current date as the issue date
            checkoutRecord.setDueDate(LocalDate.now().plusWeeks(3)); // Set due date to 3 weeks from issue date
            checkoutRecord.setReturnStatus(ReturnStatus.valueOf("NOT_REQUESTED")); // Set initial return status

            // Save the checkout record to the repository
            checkoutRecordRepository.save(checkoutRecord);

            // Update the available copies of the book after checkout
            book.setAvailableCopies(book.getAvailableCopies() - 1); // Decrease available copies by 1
            bookRepository.save(book); // Save the updated book to the repository

            // Return success message with due date information
            return "Successfully checked out! Due date: " + checkoutRecord.getDueDate();
        } else {
            // If no copies are available, return an error message
            return "No copies available for checkout.";
        }
    }

    // Helper method to check if the user has any overdue books
    public boolean hasOverdueBooks(Long userId) {
        // Retrieve the user by their ID
        Optional<User> optionalUser = userRepository.findById(userId);

        // If user is not found, return false (no overdue books)
        if (optionalUser.isEmpty()) {
            return false;
        }

        User user = optionalUser.get(); // Get the user object
        LocalDate today = LocalDate.now(); // Get the current date

        // Find all checkout records associated with the user
        List<CheckoutRecord> checkoutRecords = checkoutRecordRepository.findByUser(user);

        // Iterate through each checkout record to check for overdue books
        for (CheckoutRecord record : checkoutRecords) {
            // If the due date is before today, the book is overdue
            if (record.getDueDate() != null && record.getDueDate().isBefore(today)) {
                return true; // Overdue book found
            }
        }

        // Return false if no overdue books were found
        return false;
    }

    // Method to get the list of books currently checked out by a user
    public List<Book> getCheckedOutBooksForUser(Long userId) {
        // Retrieve the user by their ID
        Optional<User> optionalUser = userRepository.findById(userId);
        // If user is not found, return an empty list
        if (optionalUser.isEmpty()) {
            return new ArrayList<>();
        }

        User user = optionalUser.get(); // Get the user object
        // Retrieve all checkout records for the user
        List<CheckoutRecord> checkoutRecords = checkoutRecordRepository.findByUser(user);
        List<Book> checkedOutBooks = new ArrayList<>(); // List to hold checked out books

        // Iterate through each checkout record and add the corresponding books to the list
        for (CheckoutRecord record : checkoutRecords) {
            checkedOutBooks.add(record.getBook());
        }

        // Return the list of checked out books
        return checkedOutBooks;
    }

    // Method to add a user to the waitlist for a specific book
    public String addUserToWaitlist(Long userId, Long bookId) {
        // Retrieve the user and book from their respective repositories
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Book> optionalBook = bookRepository.findById(bookId);

        // Check if the user exists; if not, return an error message
        if (optionalUser.isEmpty()) {
            return "User not found.";
        }
        // Check if the book exists; if not, return an error message
        if (optionalBook.isEmpty()) {
            return "Book not found.";
        }

        User user = optionalUser.get(); // Get the user object
        Book book = optionalBook.get(); // Get the book object

        // Check if the user is already on the waitlist for this specific book
        if (book.getWaitlist().contains(user)) {
            return "You are already on the waitlist for this book.";
        }

        // Check if the user is already on the waitlist for 5 books
        long waitlistedBooksCount = getWaitlistedBooksCount(userId);
        if (waitlistedBooksCount >= 5) {
            return "You cannot be on the waitlist for more than 5 books.";
        }

        // Add the user to the waitlist for the book
        book.addUserToWaitlist(user);
        bookRepository.save(book); // Save the updated book with the new waitlist

        // Return confirmation message
        return "You have been added to the waitlist for this book.";
    }

    // Method to count how many books a user is waitlisted for
    public long getWaitlistedBooksCount(Long userId) {
        // Retrieve the user by their ID
        Optional<User> optionalUser = userRepository.findById(userId);
        // If user is not found, return 0
        if (optionalUser.isEmpty()) {
            return 0;
        }

        User user = optionalUser.get(); // Get the user object

        // Count how many books the user is on the waitlist for across all books
        return bookRepository.findAll().stream()
                .filter(book -> book.getWaitlist().contains(user)) // Filter books by checking if the user is on the waitlist
                .count(); // Return the count
    }

    // Method to retrieve all books a user is waitlisted for
    public List<Book> getWaitlistedBooksForUser(Long userId) {
        // Retrieve the user by their ID
        Optional<User> optionalUser = userRepository.findById(userId);
        List<Book> waitlistedBooks = new ArrayList<>(); // List to hold waitlisted books

        // If the user exists, check which books they are on the waitlist for
        if (optionalUser.isPresent()) {
            User user = optionalUser.get(); // Get the user object
            // Retrieve all books from the repository
            bookRepository.findAll().forEach(book -> {
                // If the user is on the waitlist for this book, add it to the waitlisted books list
                if (book.getWaitlist().contains(user)) {
                    waitlistedBooks.add(book);
                }
            });
        }

        // Return the list of waitlisted books
        return waitlistedBooks;
    }

    // Method to handle return requests for books
    public String requestReturn(Long userId, Long bookId) {
        // Retrieve the user and book from their respective repositories
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Book> optionalBook = bookRepository.findById(bookId);

        // Check if user or book exists; if not, return an error message
        if (optionalUser.isEmpty() || optionalBook.isEmpty()) {
            return "User or Book not found.";
        }

        User user = optionalUser.get(); // Get the user object
        Book book = optionalBook.get(); // Get the book object

        // Check if a return request already exists for this user and book
        List<ReturnRequest> existingRequests = returnRequestRepository.findByUserAndBook(user, book);
        if (!existingRequests.isEmpty()) {
            return "Return request already exists."; // Return message if request already exists
        }

        // Create a new return request
        ReturnRequest returnRequest = new ReturnRequest();
        returnRequest.setUser(user); // Set the user for the return request
        returnRequest.setBook(book); // Set the book for the return request
        returnRequest.setRequestDate(LocalDateTime.now()); // Set the current date and time for the request
        returnRequest.setApproved(false); // Default to not approved

        // Save the return request to the repository
        returnRequestRepository.save(returnRequest);

        // Return confirmation message
        return "Return request submitted successfully!";
    }

    // Method to get the user's position on the waitlist for a specific book
    public String getUserWaitlistPosition(Long userId, Long bookId) {
        // Retrieve the user and book from their respective repositories
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Book> optionalBook = bookRepository.findById(bookId);

        // Check if user or book exists; if not, return an error message
        if (optionalUser.isEmpty() || optionalBook.isEmpty()) {
            return "User or Book not found.";
        }

        User user = optionalUser.get(); // Get the user object
        Book book = optionalBook.get(); // Get the book object

        // Get the waitlist for the book
        List<User> waitlist = book.getWaitlist();

        // Check if the user is on the waitlist and retrieve their position
        int position = waitlist.indexOf(user);
        if (position != -1) {
            // If user is on the waitlist, return their position (1-based)
            return "You are number " + (position + 1) + " on the waitlist for this book.";
        } else {
            // If user is not on the waitlist, return appropriate message
            return "You are not on the waitlist for this book.";
        }
    }

    // Method to retrieve all checkout records for a user
    public List<CheckoutRecord> getCheckedOutRecordsForUser(Long userId) {
        // Retrieve the user by their ID
        Optional<User> optionalUser = userRepository.findById(userId);
        // If user is not found, return an empty list
        if (optionalUser.isEmpty()) {
            return new ArrayList<>(); // Return empty list if user is not found
        }

        User user = optionalUser.get(); // Get the user object
        // Retrieve and return all checkout records associated with the user
        return checkoutRecordRepository.findByUser(user); // Ensure this method exists
    }

    // Method to register a new user
    public String registerUser(User user) {
        // Check if a user with the same username already exists
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists."); // Throw exception if username is taken
        }

        // Save the new user to the database
        userRepository.save(user);

        // Return success message
        return "User registered successfully.";
    }
}
