package com.example.LibraryManagement.model;

import jakarta.persistence.*;

// Entity representing an Admin in the library management system
@Entity
@Table(name = "ADMIN") // Adjust the table name if needed
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate ID
    private Long id; // Unique identifier for the admin

    private String name; // Name of the admin
    private String role; // Role of the admin (e.g., super admin, library manager)

    // Use only the admin password for authentication
    private String adminPassword; // Password for admin authentication

    private String adminUsername; // Username for the admin account

    // Default constructor
    public Admin() {}

    // Parameterized constructor to initialize admin details
    public Admin(String name, String role, String adminPassword, String adminUsername) {
        this.name = name;
        this.role = role;
        this.adminPassword = adminPassword;
        this.adminUsername = adminUsername;
    }

    // Getters and Setters for accessing and modifying admin properties
    public Long getId() {
        return id; // Get the unique identifier
    }

    public void setId(Long id) {
        this.id = id; // Set the unique identifier
    }

    public String getName() {
        return name; // Get the name of the admin
    }

    public void setName(String name) {
        this.name = name; // Set the name of the admin
    }

    public String getAdminPassword() {
        return adminPassword; // Get the admin password
    }
}
