package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.service.LibraryService;
import com.example.LibraryManagement.service.ReturnRequestService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ReturnRequestController {

    @Autowired
    private LibraryService libraryService; // Service for library operations

    @Autowired
    private ReturnRequestService returnRequestService; // Service for handling return requests

    // GET request for user dashboard
    @GetMapping("/userDashboard")
    public String showUserDashboard(HttpSession session, Model model) {
        // Retrieve the user from the session
        User user = (User) session.getAttribute("user");
        // Check if the user is logged in
        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }
        // Add the user to the model to access it in the view
        model.addAttribute("user", user);
        return "userDashboard";  // Render the user dashboard page
    }

    // GET request for return request page
    @GetMapping("/requestReturnPage")
    public String showReturnRequestPage(HttpSession session, Model model) {
        // Retrieve the user from the session
        User user = (User) session.getAttribute("user");
        // Check if the user is logged in
        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        // Get checkout records for the logged-in user
        List<CheckoutRecord> checkoutRecords = libraryService.getCheckedOutRecordsForUser(user.getUserId());
        // Add the checkout records to the model for the view
        model.addAttribute("checkoutRecords", checkoutRecords);
        return "returnRequestPage";  // Render the return request page
    }

    // POST request to handle return request submission
    @PostMapping("/requestReturn")
    public String requestReturn(@RequestParam("bookId") Long bookId, HttpSession session, Model model) {
        // Retrieve the user from the session
        User user = (User) session.getAttribute("user");
        // Check if the user is logged in
        if (user == null) {
            return "redirect:/user/dashboard"; // Redirect to user dashboard if user is not logged in
        }

        // Pass only userId and bookId to the service to create a return request
        String message = returnRequestService.createReturnRequest(user.getUserId(), bookId);

        // Store the result message in the model for display on the return request page
        model.addAttribute("message", message);

        // Update the checkout records after the return request
        List<CheckoutRecord> checkoutRecords = libraryService.getCheckedOutRecordsForUser(user.getUserId());
        // Pass the updated records to the model
        model.addAttribute("checkoutRecords", checkoutRecords);

        return "returnRequestPage";  // Redirect back to the return request page
    }
}
