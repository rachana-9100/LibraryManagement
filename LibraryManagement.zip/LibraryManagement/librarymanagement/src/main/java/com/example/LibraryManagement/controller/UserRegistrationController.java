package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.service.UserRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller  // Marks this class as a Spring MVC controller
public class UserRegistrationController {

    @Autowired  // Automatically injects the UserRegistrationService to handle user registration logic
    private UserRegistrationService userRegistrationService;

    /**
     * Displays the user registration form.
     * This method is mapped to the "/register" URL and responds to GET requests.
     *
     * @param model The Model object used to pass data to the view.
     * @return The name of the view for the registration form (registration.html).
     */
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        // Add an empty User object to the model to bind form data to
        model.addAttribute("user", new User());  // Creates a new empty User object for form binding
        return "registration";  // Return the registration form view (registration.html)
    }

    /**
     * Handles user registration when the form is submitted.
     * This method is mapped to the "/register" URL and responds to POST requests.
     *
     * @param user The User object containing the data submitted in the registration form.
     * @param model The Model object used to pass data to the view.
     * @return The name of the view for the registration form (registration.html) with a success or error message.
     */
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        // Call the service to register the user and return a message (success or failure)
        String message = userRegistrationService.registerUser(user);

        // Add the registration message to the model (e.g., "User registered successfully" or "Registration failed")
        model.addAttribute("message", message);

        // Return the registration view with the registration message
        return "registration";  // Return the same view (registration.html) to show the message
    }
}
