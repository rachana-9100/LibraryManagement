package com.example.LibraryManagement.repository;

import com.example.LibraryManagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

// Repository interface for User entity
public interface UserRepository extends JpaRepository<User, Long> {

    // Query to find a User by their username and password
    User findByUsernameAndPassword(String username, String password);

    // Check if a User with the given email already exists
    boolean existsByEmail(String email);

    // Check if a User with the given name already exists
    boolean existsByName(String name);

    // Check if a User with the given username already exists
    boolean existsByUsername(String username);
}
