package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.ReturnRequest;
import com.example.LibraryManagement.model.ReturnStatus;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.ReturnRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.time.LocalDateTime;
import java.util.List;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;

@Service
public class AdminReturnRequestService {

    // Repositories for interacting with the database
    private CheckoutRecordRepository checkoutRecordRepository;
    private BookRepository bookRepository;

    @Autowired
    private ReturnRequestRepository returnRequestRepository;

    // Default constructor
    public AdminReturnRequestService() {
    }

    // Method to get all pending return requests
    public List<ReturnRequest> getPendingReturnRequests() {
        // Fetch only the return requests with 'pending' status
        return returnRequestRepository.findByStatus("pending");
    }

    // Method to approve a return request by its ID
    public String approveReturnRequest(Long requestId) {
        Optional<ReturnRequest> returnRequestOpt = returnRequestRepository.findById(requestId);
        if (returnRequestOpt.isPresent()) {
            ReturnRequest returnRequest = returnRequestOpt.get();
            returnRequest.setApproved(true); // Mark the request as approved
            returnRequest.setStatus("approved"); // Update status to approved
            returnRequest.setApprovalDate(LocalDateTime.now()); // Set the approval date
            returnRequestRepository.save(returnRequest); // Save changes to the return request

            // Update the corresponding checkout record
            CheckoutRecord checkoutRecord = returnRequest.getCheckoutRecord();
            checkoutRecord.setReturnStatus(ReturnStatus.APPROVED); // Update status in checkout record
            checkoutRecordRepository.save(checkoutRecord); // Save changes to the checkout record

            // Update the book's available copies
            Book book = returnRequest.getBook();
            book.setAvailableCopies(book.getAvailableCopies() + 1); // Increment available copies
            bookRepository.save(book); // Save changes to the book

            return "Return request approved successfully!"; // Return success message
        } else {
            return "Return request not found."; // Return error message if request ID is invalid
        }
    }

    // Method to reject a return request by its ID
    public String rejectReturnRequest(Long requestId) {
        Optional<ReturnRequest> returnRequestOpt = returnRequestRepository.findById(requestId);
        if (returnRequestOpt.isPresent()) {
            ReturnRequest returnRequest = returnRequestOpt.get();
            returnRequest.setApproved(false); // Mark the request as not approved
            returnRequest.setStatus("rejected"); // Update status to rejected
            returnRequest.setApprovalDate(null); // Clear the approval date if rejected
            returnRequestRepository.save(returnRequest); // Save changes to the return request

            return "Return request rejected successfully!"; // Return success message
        } else {
            return "Return request not found."; // Return error message if request ID is invalid
        }
    }
}
