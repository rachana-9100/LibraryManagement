package com.example.LibraryManagement;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Component
public class BookInitializer implements CommandLineRunner {

    @Autowired
    private BookRepository bookRepository; // Repository to interact with the book database

    @Autowired
    private BookService bookService; // Service layer for book-related operations

    Random random = new Random(); // Random number generator for available copies

    // Method to add a list of books to the database
    public void addBooks(List<Book> books) {
        for (Book book : books) {
            // Check if the book already exists in the database by title and author
            List<Book> existingBooks = bookRepository.findByTitleAndAuthor(book.getTitle(), book.getAuthor());
            if (existingBooks.isEmpty()) {
                bookRepository.save(book);  // Save the book if it doesn't already exist
            }
        }
    }

    // This method is called at application startup
    public void run(String... args) throws Exception {
        try {
            // Generate random number of available copies between 1 and 8
            int randomCopies1 = random.nextInt(8) + 1;
            int randomCopies2 = random.nextInt(8) + 1;
            int randomCopies3 = random.nextInt(8) + 1;

            // Create some book instances with coverImageUrl
            Book book1 = new Book("The Catcher in the Rye", "J.D. Salinger", randomCopies1);
            book1.setCoverImageUrl("https://example.com/catcher-cover.jpg"); // Set cover image URL

            Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", randomCopies2);
            book2.setCoverImageUrl("https://example.com/mockingbird-cover.jpg"); // Set cover image URL

            Book book3 = new Book("1984", "George Orwell", randomCopies3);
            book3.setCoverImageUrl("https://example.com/1984-cover.jpg"); // Set cover image URL

            // Add books to the BOOK table using the book service
            bookService.addBooks(Arrays.asList(book1, book2, book3));

            // Output the list of books with their randomly assigned copies to the console
            System.out.println("Books added to the BOOK table:");
            bookService.getAllBooks().forEach(System.out::println); // Print all books in the database
        } catch (Exception e) {
            // Log any errors that occur during the initialization process
            System.err.println("An error occurred while initializing books: " + e.getMessage());
        }
    }
}
