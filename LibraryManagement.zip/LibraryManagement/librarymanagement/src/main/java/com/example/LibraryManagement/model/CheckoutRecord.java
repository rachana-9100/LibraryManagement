package com.example.LibraryManagement.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// Entity representing a checkout record in the library management system
@Entity
@Table(name = "CHECKOUT_RECORD") // Table name in the database
public class CheckoutRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate the primary key
    private Long checkoutRecordId; // Primary key for checkout records

    // Relationship with the Book entity
    @ManyToOne
    @JoinColumn(name = "BOOK_ID", nullable = false) // Foreign key to the BOOK_ID column
    private Book book; // The book being checked out

    // Relationship with the User entity
    @ManyToOne
    @JoinColumn(name = "USER_ID", nullable = false) // Foreign key to the USER_ID column
    private User user; // The user who checked out the book
    @OneToMany(mappedBy = "checkoutRecord", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ReturnRequest> returnRequests = new ArrayList<>();

    private LocalDate issueDate; // Date when the book was issued
    private LocalDate dueDate; // Date when the book is due

    @Enumerated(EnumType.STRING) // Store enum as a string in the database
    @Column(name = "RETURN_STATUS") // Column name for return status
    private ReturnStatus returnStatus = ReturnStatus.NOT_REQUESTED;  // Default value for return status

    // Getters and Setters

    public Book getBook() {
        return book; // Get the book associated with this checkout record
    }



    public void setBook(Book book) {
        this.book = book; // Set the book for this checkout record
    }

    public User getUser() {
        return user; // Get the user associated with this checkout record
    }

    public void setUser(User user) {
        this.user = user; // Set the user for this checkout record
    }

    public LocalDate getIssueDate() {
        return issueDate; // Get the date the book was issued
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate; // Set the issue date for this checkout record
    }

    public LocalDate getDueDate() {
        return dueDate; // Get the due date for the checked out book
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate; // Set the due date for this checkout record
    }

    public ReturnStatus getReturnStatus() {
        return returnStatus; // Get the return status of the book
    }

    public void setReturnStatus(ReturnStatus returnStatus) {
        this.returnStatus = returnStatus; // Set the return status for this checkout record
    }
}
