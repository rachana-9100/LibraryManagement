package com.example.LibraryManagement.repository;

import com.example.LibraryManagement.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository // Marks this interface as a Spring Data repository
public interface BookRepository extends JpaRepository<Book, Long> {
    // Inherits default CRUD operations from JpaRepository

    // Custom native query to fetch random books
    // This query selects 10 random books from the "Book" table
    @Query(value = "SELECT * FROM Book ORDER BY RAND() LIMIT 10", nativeQuery = true)
    List<Book> findRandomBooks();

    // Method to find books by both title and author (exact match)
    List<Book> findByTitleAndAuthor(String title, String author);

    // Custom JPQL query for searching books by title or author (case-insensitive)
    // Uses SQL LIKE operator to find books where the title or author contains the query string
    @Query("SELECT b FROM Book b WHERE LOWER(b.title) LIKE LOWER(CONCAT('%', :query, '%')) " +
            "OR LOWER(b.author) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Book> searchBooks(@Param("query") String query);

    // Method to search books by title or author (partial match)
    // Looks for books where the title or author contains the given string (case-insensitive)
    List<Book> findByTitleContainingOrAuthorContaining(String title, String author);

    // Method to find all books that are marked as "featured"
    List<Book> findByFeatured(boolean featured);
}
