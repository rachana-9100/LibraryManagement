package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import com.example.LibraryManagement.service.BookService;
import com.example.LibraryManagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AdminUserController {

    // Autowire the CheckoutRecordRepository to access checkout records from the database
    @Autowired
    private CheckoutRecordRepository checkoutRecordRepository;

    // Autowire the BookService to handle book-related operations
    @Autowired
    private BookService bookService;

    // Autowire the UserService to handle user-related operations
    @Autowired
    private UserService userService;

    /**
     * View all users and their checkout records.
     * This method is mapped to the URL "/admin/users" and responds to GET requests.
     * It fetches all users, retrieves their checkout records, and passes them to the model.
     *
     * @param model The Model object to pass data to the view.
     * @return The name of the Thymeleaf template to render the user list.
     */
    @GetMapping("/admin/users")
    public String viewUsers(Model model) {
        // Fetch the list of all users using the UserService
        List<User> users = userService.getAllUsers();

        // Loop through each user to get their associated checkout records
        for (User user : users) {
            // Fetch checkout records for the current user from the CheckoutRecordRepository
            List<CheckoutRecord> checkoutRecords = checkoutRecordRepository.findByUser(user);

            // Assuming the User entity has a list of CheckoutRecords, set it for each user
            user.setCheckoutRecords(checkoutRecords);
        }

        // Add the list of users (with their checkout records) to the model to be displayed in the view
        model.addAttribute("users", users);

        // Return the Thymeleaf template for displaying the list of users
        return "admin_users"; // Points to the Thymeleaf template 'admin_users.html'
    }

    /**
     * View all books.
     * This method is mapped to the URL "/admin/books" and responds to GET requests.
     * It fetches all books and passes them to the model for display.
     *
     * @param model The Model object to pass data to the view.
     * @return The name of the Thymeleaf template to render the book list.
     */
    @GetMapping("/admin/books")
    public String viewBooks(Model model) {
        // Fetch the list of all books using the BookService
        List<Book> books = bookService.getAllBooks();

        // Add the list of books to the model to be displayed in the view
        model.addAttribute("books", books);

        // Return the Thymeleaf template for displaying the list of books
        return "admin_books";  // Ensure the view name matches the Thymeleaf template 'admin_books.html'
    }
}
