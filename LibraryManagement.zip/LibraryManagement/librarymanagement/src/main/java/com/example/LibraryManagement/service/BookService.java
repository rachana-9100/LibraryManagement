package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.UserRepository;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service  // Marks this class as a service, allowing it to be autowired in other components
public class BookService {

    @Autowired
    private BookRepository bookRepository;  // Repository for handling Book database operations

    @Autowired
    private UserRepository userRepository;  // Repository for handling User database operations

    @Autowired
    private CheckoutRecordRepository checkoutRecordRepository;  // Repository for handling CheckoutRecord operations

    // Fetch all books from the repository
    public List<Book> getAllBooks() {
        return bookRepository.findAll();  // Retrieve all books from the database
    }

    // Fetch books that are available (i.e., have copies available for checkout)
    public List<Book> getAvailableBooks() {
        return bookRepository.findAll().stream()
                .filter(book -> book.getAvailableCopies() > 0)  // Only include books with available copies
                .toList();  // Convert stream to list
    }

    // Fetch a specific book by its ID
    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);  // Find a book by its ID
    }

    // Add a user to the waitlist for a book
    public String addUserToWaitlist(Long bookId, Long userId) {
        Optional<Book> optionalBook = bookRepository.findById(bookId);  // Get the book by ID
        Optional<User> optionalUser = userRepository.findById(userId);  // Get the user by ID

        if (optionalBook.isEmpty() || optionalUser.isEmpty()) {
            return "Book or User not found.";  // Return error message if book or user is not found
        }

        Book book = optionalBook.get();  // Get the book object
        User user = optionalUser.get();  // Get the user object

        // Add user to the book's waitlist
        book.addUserToWaitlist(user);

        // Save the updated book in the repository (with updated waitlist)
        bookRepository.save(book);

        return "User " + user.getName() + " added to the waitlist for the book " + book.getTitle() + ".";  // Return success message
    }

    // Check if a user has any overdue books
    public boolean hasOverdueBooks(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);  // Get the user by ID

        if (optionalUser.isEmpty()) {
            return false;  // Return false if the user is not found
        }

        User user = optionalUser.get();
        LocalDate today = LocalDate.now();  // Get today's date

        // Loop through the user's checkout records to check for overdue books
        List<CheckoutRecord> checkoutRecords = checkoutRecordRepository.findByUser(user);
        for (CheckoutRecord record : checkoutRecords) {
            if (record.getDueDate() != null && record.getDueDate().isBefore(today)) {
                return true;  // Return true if any book is overdue
            }
        }

        return false;  // Return false if no overdue books are found
    }

    // Save a book to the database
    public void saveBook(Book book) {
        bookRepository.save(book);  // Save the book in the repository
    }

    // Remove a user from the waitlist after a book is issued
    public String removeUserFromWaitlist(Long bookId, Long userId) {
        Optional<Book> optionalBook = bookRepository.findById(bookId);  // Get the book by ID
        Optional<User> optionalUser = userRepository.findById(userId);  // Get the user by ID

        if (optionalBook.isEmpty() || optionalUser.isEmpty()) {
            return "Book or User not found.";  // Return error message if book or user is not found
        }

        Book book = optionalBook.get();  // Get the book object
        User user = optionalUser.get();  // Get the user object

        // Remove the user from the book's waitlist
        book.getWaitlist().remove(user);

        // Save the updated book in the repository
        bookRepository.save(book);

        return "User " + user.getName() + " removed from the waitlist.";  // Return success message
    }

    // Get the number of users on the waitlist for a specific book
    public int getWaitlistCount(Long bookId) {
        Optional<Book> optionalBook = bookRepository.findById(bookId);  // Get the book by ID

        if (optionalBook.isEmpty()) {
            return 0;  // Return 0 if the book is not found
        }

        return optionalBook.get().getWaitlist().size();  // Return the size of the waitlist
    }

    // Add a list of books to the database
    public void addBooks(List<Book> books) {
        for (Book book : books) {
            List<Book> existingBooks = bookRepository.findByTitleAndAuthor(book.getTitle(), book.getAuthor());
            if (existingBooks.isEmpty()) {
                bookRepository.save(book);  // Save the book if it doesn't already exist in the repository
            }
        }
    }

    // Search for books by title or author (case-insensitive, partial match)
    public List<Book> searchBooks(String query) {
        return bookRepository.searchBooks(query);  // Use repository search to find books by query
    }

    // Fetch random books (for displaying random selections, such as a "Featured" section)
    public List<Book> getRandomBooks() {
        return bookRepository.findRandomBooks();  // Fetch random books from the repository
    }

    // Fetch only books that are marked as featured
    public List<Book> getFeaturedBooks() {
        return bookRepository.findByFeatured(true);  // Retrieve books where the "featured" flag is true
    }
}
