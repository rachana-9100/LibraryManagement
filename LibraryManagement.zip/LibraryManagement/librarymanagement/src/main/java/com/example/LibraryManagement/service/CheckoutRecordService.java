package com.example.LibraryManagement.service;

import com.example.LibraryManagement.model.Book;
import com.example.LibraryManagement.model.CheckoutRecord;
import com.example.LibraryManagement.model.ReturnStatus;
import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.BookRepository;
import com.example.LibraryManagement.repository.CheckoutRecordRepository;
import com.example.LibraryManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service  // Marks this class as a Spring service, which will be autowired into other components
public class CheckoutRecordService {

    @Autowired  // Automatically inject the CheckoutRecordRepository
    private CheckoutRecordRepository checkoutRecordRepository;

    @Autowired  // Automatically inject the UserRepository
    private UserRepository userRepository;

    @Autowired  // Automatically inject the BookRepository
    private BookRepository bookRepository;

    // Method to issue a book to a user by bookId and userId
    public String issueBookToUser(Long bookId, Long userId) {
        // Fetch the user by userId
        User user = userRepository.findById(userId).orElse(null);
        // Fetch the book by bookId
        Book book = bookRepository.findById(bookId).orElse(null);

        // If user is not found, return an error message
        if (user == null) {
            return "Error: User not found.";
        }
        // If book is not found, return an error message
        if (book == null) {
            return "Error: Book not found.";
        }

        // Check if the user already has this book checked out and hasn't returned it yet
        List<CheckoutRecord> existingCheckoutRecords = checkoutRecordRepository.findByUserAndBook(user, book);
        for (CheckoutRecord record : existingCheckoutRecords) {
            if (record.getReturnStatus() != ReturnStatus.APPROVED) {  // Check if the book is already checked out
                return "The User already has this book checked out and it has not been returned.";
            }
        }

        // If no available copies of the book, return an error message
        if (book.getAvailableCopies() <= 0) {
            return "Error: No available copies of this book.";
        }

        // Create a new checkout record
        CheckoutRecord checkoutRecord = new CheckoutRecord();
        checkoutRecord.setUser(user);  // Set the user in the checkout record
        checkoutRecord.setBook(book);  // Set the book in the checkout record
        checkoutRecord.setIssueDate(LocalDate.now());  // Set the issue date to the current date
        checkoutRecord.setDueDate(LocalDate.now().plusDays(21));  // Set the due date to 21 days after the issue date

        // Save the new checkout record
        checkoutRecordRepository.save(checkoutRecord);

        // Decrease the number of available copies of the book by 1
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        // Save the updated book entity
        bookRepository.save(book);

        // Return a success message with the user's name
        return "Success: Book issued to " + user.getName() + "!";
    }
}
