package com.example.LibraryManagement.model;

// Enum representing the status of a return request in the library management system
public enum ReturnStatus {
    NOT_REQUESTED, // Status indicating that no return request has been made
    PENDING,       // Status indicating that the return request is pending approval
    REQUESTED,     // Status indicating that the return request has been made
    APPROVED,      // Status indicating that the return request has been approved
}
