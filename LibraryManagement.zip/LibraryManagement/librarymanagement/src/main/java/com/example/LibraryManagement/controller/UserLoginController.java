package com.example.LibraryManagement.controller;

import com.example.LibraryManagement.model.User;
import com.example.LibraryManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;

@Controller  // Marks this class as a Spring MVC controller
public class UserLoginController {

    @Autowired  // Automatically injects the UserRepository dependency to access user-related data
    private UserRepository userRepository;

    /**
     * Displays the user login form.
     * This method is mapped to the URL "/userlogin" and responds to GET requests.
     *
     * @return The view name for the user login form (user_login.html).
     */
    @GetMapping("/userlogin")
    public String showUserLoginForm() {
        return "user_login";  // Points to the Thymeleaf template 'user_login.html'
    }

    /**
     * Handles the user login submission.
     * This method is mapped to the URL "/userlogin" and responds to POST requests.
     *
     * @param username The username entered by the user.
     * @param password The password entered by the user.
     * @param session The HttpSession object to store session data.
     * @param model The Model object to pass data to the view.
     * @return A redirect to the user dashboard on success, or back to the login page with an error message on failure.
     */
    @PostMapping("/userlogin")
    public String userLogin(@RequestParam("username") String username,
                            @RequestParam("password") String password,
                            HttpSession session,
                            Model model) {
        // Find the user by username and password (assuming plain-text validation, which is not recommended)
        User user = userRepository.findByUsernameAndPassword(username, password);

        // If the user is found (valid credentials), log them in
        if (user != null) {
            session.setAttribute("user", user);  // Store the user in the session
            return "redirect:/user_dashboard";  // Redirect to the user dashboard after successful login
        } else {
            // If the credentials are invalid, show an error message
            model.addAttribute("error", "Invalid username or password.");  // Add the error message to the model
            return "user_login";  // Return to the login page with the error message
        }
    }

    /**
     * Displays the user dashboard after login.
     * This method is mapped to the URL "/user_dashboard" and responds to GET requests.
     *
     * @param session The HttpSession object to check if the user is logged in.
     * @param model The Model object to pass data to the view.
     * @return The user dashboard if the session is valid, otherwise redirects to the login page.
     */
    @GetMapping("/user_dashboard")
    public String showUserDashboard(HttpSession session, Model model) {
        // Check if the user is logged in by retrieving the "user" attribute from the session
        User user = (User) session.getAttribute("user");

        // If the user is not found in the session (i.e., not logged in), redirect to the login page
        if (user == null) {
            return "redirect:/userlogin";  // Redirect to the login page
        }

        // Pass the logged-in user's data to the dashboard view
        model.addAttribute("user", user);  // Add the user object to the model
        return "user_dashboard";  // Render 'user_dashboard.html'
    }

    // Other user-related methods (e.g., logout) can go here
}
