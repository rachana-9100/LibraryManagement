package com.example.LibraryManagement.controller;

import jakarta.servlet.http.HttpSession;  // Import to manage session handling
import org.springframework.stereotype.Controller;  // Import to define this class as a controller
import org.springframework.web.bind.annotation.GetMapping;  // Import to map the GET request

@Controller  // Marks this class as a Spring MVC controller
public class LogoutController {

    /**
     * Handles the user logout process.
     * This method is mapped to the "/logout" URL and responds to GET requests.
     * It invalidates the current session and redirects the user to the homepage.
     *
     * @param session The HttpSession object that manages the user's session.
     * @return A redirect to the homepage ("/").
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // Invalidate the current session, logging out the user by removing any session attributes
        session.invalidate();

        // Redirect the user to the homepage (root path "/") after logging out
        return "redirect:/";  // This will trigger a client-side redirect to the homepage
    }
}
