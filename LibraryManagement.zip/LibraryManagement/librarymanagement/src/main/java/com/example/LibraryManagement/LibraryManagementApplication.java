package com.example.LibraryManagement; // Ensure this matches your package structure

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // This annotation enables auto-configuration, component scanning, and configuration properties in Spring Boot
public class LibraryManagementApplication {

    // Main entry point for the Spring Boot application
    public static void main(String[] args) {
        // Launches the Spring Boot application, which initializes the Spring context, beans, and services
        SpringApplication.run(LibraryManagementApplication.class, args);
    }
}
