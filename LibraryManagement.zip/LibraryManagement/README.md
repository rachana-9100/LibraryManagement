
# Library Management System - Book Checkout and Return Module

## Overview

This project is a simple module for a Library Management System that allows users to check out and return e-books. The system includes features such as book availability, waitlisting, and the management of overdue books. The system is built using **Java**, **Spring Boot**, **H2 in-memory database**, and **JUnit 5** for testing.

## Features

- Users can check out available books from the library.
- If all copies of a book are checked out, users can be added to a waitlist.
- Users can be on the waitlist for a maximum of 5 books.
- Books can only be checked out for a maximum of 3 weeks.
- Users cannot check out new books if they have overdue books.
- Users can only check out one copy of each book at a time,but they can check out any number of different books.
- Users can re-checkout a book after returning it, provided it is available.
- Users can query their waitlist position for a specific book.
- Admins can issue books and manage return requests.
- Unit tests are provided to test the core functionality of the system.

## Tech Stack

- **Programming Language:** Java
- **Framework:** Spring Boot (for RESTful API development)
- **Database:** H2 (in-memory database for simplicity)=----[I used a file-based H2 database instead of in-memory to ensure that the data persists between application restarts, which prevents the loss of records during testing and development.]
- **Build Tool:** Maven
- **Testing Framework:** JUnit 5

## Setup Instructions

### Prerequisites

- **JDK 17** or later
- **Maven** (to manage dependencies and run the project)
- A compatible **IDE** (e.g., IntelliJ IDEA, Eclipse)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/library-management-system.git
   ```
2. Navigate into the project directory:
   ```bash
   cd library-management-system
   ```
3. Build the project using Maven:
   ```bash
   mvn clean install
   ```

### Running the Application

1. Start the application using the Maven command:
   ```bash
   mvn spring-boot:run
   ```
2. The application will start on `http://localhost:8083`.

### Database

This project uses **H2**, an in-memory database. The database schema is automatically created when the application starts.

To access the H2 console:

- URL: `http://localhost:8083/h2-console`
- Driver Class: `org.h2.Driver`
- JDBC URL: `jdbc:h2:file:~/library2`
- Username: `sa`
- Password: (leave it blank)

### REST API Endpoints

Here are the key endpoints for this module:

- **User Endpoints:**
  - `GET /checkoutbook`: View available books for checkout.
  - `POST /checkoutbook`: Check out a book by providing a `bookId`.
  - `POST /waitlist`: Add a user to the waitlist for a book.
  - `POST /waitlistPosition`: Check the user’s position on the waitlist for a specific book.

- **Admin Endpoints:**
  - `GET /admin/issue-books`: View books available for issuing.
  - `POST /admin/issue-book`: Issue a book to a user.
  - `POST /admin/approveReturnRequest`: Approve a return request for a book.
  - `POST /admin/rejectReturnRequest`: Reject a return request for a book.

- **Authentication:**
  - `POST /adminlogin`: Admin login.
  - `POST /userlogin`: User login.
  - `GET /logout`: Logout for both admin and users.

### Testing

The project includes unit tests to validate the core functionality of the Book Checkout and Return module.

To run the tests:
```bash
mvn test
```

### Project Structure

- **src/main/java**: Contains the Java source code, organized into controller, model, repository, and service packages.
- **src/main/resources/templates**: Contains the Thymeleaf templates for the front-end (HTML pages).
- **src/test/java**: Contains JUnit tests for the module.

### Key Classes

- `Book`: Represents a book in the library.
- `User`: Represents a library user.
- `CheckoutRecord`: Represents the record of a checked-out book.
- `ReturnRequest`: Handles the return request logic.
- `BookService`: Contains the business logic for managing books.
- `CheckoutRecordService`: Manages checkout and return operations.
- `ReturnRequestService`: Handles the approval and rejection of return requests.

### Common Scenarios

1. **Book Checkout:** Users can check out a book if there are available copies, otherwise, they will be waitlisted.
2. **Return Request:** Users submit return requests, and admins can approve or reject these requests.
3. **Overdue Books:** Users with overdue books cannot check out new ones until they return their overdue books.

### Further Improvements

- Add more robust error handling and validation.
- Implement email notifications for waitlist updates.
- Integrate a more scalable database such as PostgreSQL or MySQL.

